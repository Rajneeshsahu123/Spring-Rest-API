package com.example.demo.dto;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "addressDto")
@XmlAccessorType(XmlAccessType.FIELD)
@Data
public class AddressDto {

    @XmlElement(name ="addressId")
    private int id;
    @XmlElement(name = "addressStreet")
    private String street;

    @XmlElement(name = "addressCity")
    private String  city;

    @XmlElement(name = "addressState")
    private String state;

    @XmlElement(name = "addressZipCode")
    private String zipCode;
}
