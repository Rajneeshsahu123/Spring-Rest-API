package com.example.demo.dto;


import com.example.demo.entity.Address;
import lombok.Data;
import lombok.Getter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



/*
If we are using @XmlElement,then it should be by default on method level,otherwise we will get error while sending request in postman
,to resolve this issue we have to annotate our class with @XmlAccessorType to define on which level(i.e method
level or field level) we want it.Here @XmlAccessorType makes us eligible to annotate on the field level.
*/
@Data
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class CustomerDto {

    @XmlElement(name = "customerId")
    private int id;

    @XmlElement(name = "customerName")
    private String name;

    @XmlElement(name = "addressDto")
    private AddressDto addressDto;

}
