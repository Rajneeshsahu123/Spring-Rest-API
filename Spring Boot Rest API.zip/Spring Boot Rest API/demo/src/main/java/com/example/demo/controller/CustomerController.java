package com.example.demo.controller;

import com.example.demo.customerservice.CustomerService;
import com.example.demo.dto.CustomerDto;
import com.example.demo.entity.Customer;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@Data
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @RequestMapping("/")
    public String check() {
        return "home";
    }

    @GetMapping("/getAllCustomer")
    public List<CustomerDto> getAllCustomer(){
        return customerService.getAllCustomer();
    }
    @GetMapping("/findRecordsHaving/{ch}")
    public int findRecordHaving(@PathVariable("ch") String ch){
        return customerService.findRecordHaving(ch);
    }

    @PostMapping(value="/addCustomerThroughAllDataFormat",consumes = MediaType.ALL_VALUE)
    public ResponseEntity<String> addCustomerThroughAllDataFormat(@RequestBody CustomerDto customerDto){
        return customerService.addCustomer(customerDto);
    }

    @PostMapping(value="/addCustomerThroughJSON",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> addCustomerThroughAllJSONFormat(@RequestBody CustomerDto customerDto){
        return customerService.addCustomer(customerDto);
    }

    @PostMapping(value="/addCustomerThroughXML",consumes = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<String> addCustomerThroughAllXMLFormat(@RequestBody CustomerDto customerDto){
        return customerService.addCustomer(customerDto);
    }

    @PostMapping(value="/addRecordIfIdNotExists",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> addRecordIfIdNotExists(@RequestBody CustomerDto customerDto){
        return customerService.addRecordIfIdNotExists(customerDto);
    }
    @PostMapping(value = "/addRecordsInBulk",consumes = MediaType.ALL_VALUE)
    public ResponseEntity<String> addRecordsInBulk(@RequestBody List<CustomerDto> customerDtoList){
        return customerService.addRecordsInBulk(customerDtoList);
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateCustomer(@RequestBody CustomerDto customerDto){
        return customerService.updateCustomer(customerDto);
    }

    @DeleteMapping("/deleteById/{id}")
    public ResponseEntity<String> deleteCustomerById(@PathVariable("id") int id){
        return customerService.deleteCustomerById(id);
    }

    @GetMapping("/getCustomerById/{customerId}")
    public Optional<Customer> getCustomer(@PathVariable int customerId){
        return customerService.getCustomerById(customerId);
    }

    @DeleteMapping("/deleteAllCustomer")
    public ResponseEntity<String> deleteAllCustomer(){
        return customerService.deleteAllCustomers();
    }
}
