package com.example.demo.repository;

import com.example.demo.dto.CustomerDto;
import com.example.demo.entity.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;


public interface CustomerRepository extends JpaRepository<Customer,Integer> {
    // Custom query method to add a record only if the ID does not exist
    @Query("SELECT COUNT(e.id) FROM customer_16932 e WHERE e.id = :id")
    int countById(@Param("id") int id);

    @Query("SELECT COUNT(e.name) FROM customer_16932 e WHERE e.name like %:ch%")
    int nameHaving(@Param("ch") String ch);

    default Customer addRecordIfIdNotExists(Customer entity) {
        int id = entity.getId();

        // Check if ID already exists
        if (countById(id) == 0) {
            return save(entity); // Save the entity only if ID does not exist
        } else {
            // Handle the case when the ID already exists (perhaps throw an exception)
            throw new IllegalArgumentException("ID already exists: " + id);
        }
    }
    default int findRecordHaving(String ch) {
        int count=nameHaving(ch);
        return count;
    }
}
