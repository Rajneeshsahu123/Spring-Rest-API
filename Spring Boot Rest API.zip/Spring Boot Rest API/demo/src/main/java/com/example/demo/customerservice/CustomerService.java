package com.example.demo.customerservice;

import com.example.demo.dto.CustomerDto;
import com.example.demo.entity.Address;
import com.example.demo.entity.Customer;
import com.example.demo.repository.AddressRepositroy;
import com.example.demo.repository.CustomerRepository;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@AllArgsConstructor
@Service
public class CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AddressRepositroy addressRepositroy;

    @Autowired
    ModelMapper modelMapper;

    public List<CustomerDto> getAllCustomer(){
        List<Customer> customers=customerRepository.findAll();
        List<CustomerDto> customerDto=new ArrayList<>();
        for(Customer customer:customers){
            customerDto.add(modelMapper.map(customer,CustomerDto.class));
        }
        return customerDto;
    }

    public ResponseEntity<String> addCustomer(CustomerDto customerDto) {
        System.out.println(customerDto);
        try {
            if (customerDto == null) {
                // Handle the case where customerDto or its addressDto is null
                return ResponseEntity.badRequest().body("Invalid customer data");
            }
            Address savedAddress = addressRepositroy.save(modelMapper.map(customerDto.getAddressDto(), Address.class));
            // Handle the case where saving the address failed
            Customer customer = modelMapper.map(customerDto, Customer.class);
            customer.setAddress(savedAddress);
            customerRepository.save(customer);
            return ResponseEntity.ok("1 record inserted successfully ");
        }
        catch (IllegalArgumentException illegalArgumentException){
            illegalArgumentException.printStackTrace();
            return ResponseEntity.badRequest().body("Invalid record");
        }
        catch (ConstraintViolationException constraintViolationException){
            StringBuilder errors= new StringBuilder();
            for(ConstraintViolation<?> constraintViolation:constraintViolationException.getConstraintViolations())
                errors.append(constraintViolation.getPropertyPath()).append(" ").append(constraintViolation.getMessage()).append("\n");
            return ResponseEntity.badRequest().body(errors.toString());
        }
    }

    public ResponseEntity<String> addRecordIfIdNotExists(CustomerDto customerDto) {
        try {
            if (customerDto == null||customerDto.getAddressDto()==null) {
                // Handle the case where customerDto or its addressDto is null
                return ResponseEntity.badRequest().body("Invalid customer data");
            }
            Address savedAddress = addressRepositroy.save(modelMapper.map(customerDto.getAddressDto(), Address.class));
            // Handle the case where saving the address failed
            Customer customer = modelMapper.map(customerDto, Customer.class);
            customer.setAddress(savedAddress);
            customerRepository.addRecordIfIdNotExists(customer);
            return ResponseEntity.ok("1 record inserted successfully ");
        }
        catch (IllegalArgumentException illegalArgumentException){
            illegalArgumentException.printStackTrace();
            return ResponseEntity.badRequest().body("Invalid record");
        }
        catch (ConstraintViolationException constraintViolationException){
            StringBuilder errors= new StringBuilder();
            for(ConstraintViolation<?> constraintViolation:constraintViolationException.getConstraintViolations())
                errors.append(constraintViolation.getPropertyPath()).append(" ").append(constraintViolation.getMessage()).append("\n");
            return ResponseEntity.badRequest().body(errors.toString());
        }
    }

    public ResponseEntity<String> addRecordsInBulk(List<CustomerDto> customerDtoList) {
        List<Customer> customerList=new ArrayList<>();
        for (CustomerDto customerDto : customerDtoList)
            if (customerDto != null) customerList.add(modelMapper.map(customerDto, Customer.class));
        try{
            customerRepository.saveAll(customerList);
        }
        catch (ConstraintViolationException constraintViolationException){
            StringBuilder errors= new StringBuilder();
            for(ConstraintViolation<?> constraintViolation:constraintViolationException.getConstraintViolations())
                errors.append(constraintViolation.getPropertyPath()).append(" ").append(constraintViolation.getMessage()).append("\n");
            return ResponseEntity.badRequest().body(errors.toString());
        }
        catch (IllegalArgumentException illegalArgumentException){
            illegalArgumentException.printStackTrace();
            return ResponseEntity.badRequest().body("Invalid record");
        }
        return ResponseEntity.ok(customerList.size() + " records inserted successfully");
    }


    public int findRecordHaving(String ch){
        return customerRepository.findRecordHaving(ch);
    }

    public ResponseEntity<String> updateCustomer(CustomerDto customerDto){
        customerRepository.save(modelMapper.map(customerDto, Customer.class));
        return ResponseEntity.ok("1 record updated successfully ");
    }

    public ResponseEntity<String> deleteCustomerById(int id){
        customerRepository.deleteById(id);
        return ResponseEntity.ok("1 record has been deleted");
    }

    public ResponseEntity<String> deleteAllCustomers(){
        customerRepository.deleteAll();
        return ResponseEntity.ok("all records has deleted");
    }

    public Optional<Customer> getCustomerById(int customerId){
        return customerRepository.findById(customerId);
    }
}
